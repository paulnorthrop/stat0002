## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 7, fig.height = 5, fig.align = 'center')
knitr::opts_knit$set(global.par = TRUE)

required <- c("anscombiser")
if (!all(unlist(lapply(required, function(pkg) requireNamespace(pkg, quietly = TRUE)))))
  knitr::opts_chunk$set(eval = FALSE)

## ----message = FALSE----------------------------------------------------------
library(stat0002)

## ----echo = FALSE-------------------------------------------------------------
par(mar = c(4, 4, 1, 1))

## -----------------------------------------------------------------------------
head(exchange)
tail(exchange)
# Figure 10.1
plot(exchange, pch = 16, xlab = "Pounds sterling vs. US dollars",
     ylab = "Pounds sterling vs. Canadian dollars", bty = "l", 
     main = "Raw data")
# Calculate the log-returns
USDlogr <- diff(log(exchange$USD.GBP))
CADlogr <- diff(log(exchange$CAD.GBP))
# Figure 10.2
plot(USDlogr, CADlogr, pch = 16, xlab = "Pounds sterling vs. US dollars",
     ylab = "Pounds sterling vs. Canadian dollars", bty = "l", 
     main = "Log-returns" )

## -----------------------------------------------------------------------------
cor(x = USDlogr, y = CADlogr)
cor(x = CADlogr, y = USDlogr)
cor(x = cbind(USDlogr, CADlogr))

## -----------------------------------------------------------------------------
library(anscombiser)

## -----------------------------------------------------------------------------
cor(anscombe1)
cor(anscombe2)
cor(anscombe3)
cor(anscombe4)

## -----------------------------------------------------------------------------
cor(anscombe1, method = "spearman")
cor(anscombe2, method = "spearman")
cor(anscombe3, method = "spearman")
cor(anscombe4, method = "spearman")

