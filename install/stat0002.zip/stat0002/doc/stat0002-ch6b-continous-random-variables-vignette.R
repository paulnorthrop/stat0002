## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE)
knitr::opts_knit$set(global.par = TRUE)

## ---- include = FALSE---------------------------------------------------------
# Set a random number `seed'.  
set.seed(2601)
# Set margins globally
par(mar = c(4, 4, 1, 1))

## -----------------------------------------------------------------------------
library(stat0002)
head(aussie_births)

## -----------------------------------------------------------------------------
# Using the runif() function in the stats package
set.seed(13112019)
n <- 10
u1 <- runif(n)
u1
# Using the distributions3 package to define a U(0, 1) object U
library(distributions3)
set.seed(13112019)
U <- Uniform(0, 1)
u2 <- random(U, 10)
u2

## ---- fig.align='center', fig.width=7-----------------------------------------
lambda <- 2
u <- runif(1000)
e1 <- -log(u) / lambda
hist(e1, prob = TRUE, main = "")

## ---- fig.align='center', fig.width=7-----------------------------------------
# Calculate the sample waiting times, in minutes
w <- diff(c(0, aussie_births$time)) 
# Estimate lambda (rate of births per minute)
lambdahat <- 1 / mean(w)
# The estimate of the rate of births per hour
lambdahat * 60
# Histogram and superimposed exponential density
hist(w, prob = TRUE, breaks = 8, axes = FALSE, col = 8, ylim = c(0, 0.03),
     xlab = "time since last birth (minutes)", main = "")
axis(1, at = seq(0, 160, 20))
axis(2, at = seq(0, 0.03, 0.005))
curve(dexp(x, rate = lambdahat), add = TRUE, lwd = 2)

## ---- fig.align='center', fig.width=7-----------------------------------------
# Convert weights from grams to pounds
wt <- aussie_births$weight / 453.5
# Produce a histogram of the birth weights
hist(wt, prob = TRUE, xlab = "weight (pounds)", col = 8, main = "")

## -----------------------------------------------------------------------------
# Estimate the mean, variance and (standard deviation) of W
muhat <- mean(wt)
sigma2hat <- var(wt)
sigmahat <- sd(wt)

## -----------------------------------------------------------------------------
pnorm(10, mean = muhat, sd = sigmahat, lower.tail = FALSE)
W <- Normal(mu = muhat, sigma = sigmahat)
1 - cdf(W, 10)

## -----------------------------------------------------------------------------
pnorm(2.38)
1 - pnorm(2.38)

## -----------------------------------------------------------------------------
qnorm(0.95)
Z <- Normal(0, 1)
quantile(Z, 0.95)

