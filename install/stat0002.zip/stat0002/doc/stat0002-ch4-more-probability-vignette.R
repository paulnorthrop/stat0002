## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 7, fig.height = 5, fig.align = 'center')

## ----byhandpos----------------------------------------------------------------
0.933 * 0.03 / (0.933 * 0.03 + 0.020 * 0.97)

## ----byhandneg----------------------------------------------------------------
0.98 * 0.97 / (0.98 * 0.97 + 0.067 * 0.03)

## ----stat0002function, message = FALSE----------------------------------------
library(stat0002)
screening_test(prior = 0.03, sensitivity = 0.933, specificity = 0.98)

