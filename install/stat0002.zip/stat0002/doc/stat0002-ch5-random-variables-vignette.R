## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 7, fig.height = 5, fig.align = 'center')

## -----------------------------------------------------------------------------
# Plot the p.m.f.
x <- 0:2
px <- c(1/6, 1/2, 1/3)
plot(x, px, type = "h", axes = FALSE, ylab = "P(X = x)", xlab = "x",
     ylim = c(0, 1/2), lwd = 4, cex.lab = 1.5, cex.axis = 1.5, las = 1)
axis(1, at = 0:2, lwd = 2)
axis(2, at = c(0, sort(px)), labels = c("0", "1/6", "1/3", "1/2"), lwd = 2)

## -----------------------------------------------------------------------------
# Plot c.d.f.
x0 <- c(-0.5, 0, 0, 1, 1, 2, 2)
y0 <- c(0, 0, 1/6, 1/6, 2/3, 2/3, 1)
x1 <- c(0, 0, 1, 1, 2, 2, 2.5)
y1 <- c(0, 1/6, 1/6, 2/3, 2/3, 1, 1)
plot(c(x0, x1), c(y0, y1), axes = FALSE, ylab = "", xlab = "x", las = 1, type = "n", cex.lab = 1.5, 
     cex.axis = 1.5, lwd = 4)
segments(x0, y0, x1, y1, lty = rep(1, 7), lwd = 2, pch = 0)
axis(1, at = 0:2, labels = 0:2, pos = 0, lwd = 2)
axis(2, at = cumsum(c(0, px)), labels = c("0", "1/6", "2/3", "1"), las = 1, lwd = 2)
title(ylab = expression("P(X"<="x)"), cex.lab = 1.5, line = 2.5)
# Add lines to indicate the median of X
axis(2, at = 1 / 2, labels = "1/2", las = 1, lwd = 2)
segments(-0.5, 1 / 2, 1, 1 / 2, lty = 2)
segments(1, 0, 1, 1 / 2, lty = 2)

## -----------------------------------------------------------------------------
sum(x * px)

## -----------------------------------------------------------------------------
m <- 100
x <- 1:m
px <- (6 / pi ^ 2) / x ^ 2
mat <- cbind(c(0, x), cumsum(c(0, px)))
plot(mat[, 1], mat[, 2], pch = 20, ann  = FALSE)
title(xlab = "x", ylab = expression(P(X <= x)))
abline(h = 1, lty = 2)
tail(mat)

## ----eval = FALSE, echo = FALSE-----------------------------------------------
#  title(ylab = expression(sum(x * ~p(x), x = "x=1", m)), line = 1.75)

## -----------------------------------------------------------------------------
m <- 100
x <- 1:m
px <- (6 / pi ^ 2) / x ^ 2
s <- cumsum(x * px)
plot(x, s, pch = 20, ann = FALSE)
title(xlab = "m")
title(ylab = expression(hat(S)(m)), line = 2.25)

## ----eval= FALSE--------------------------------------------------------------
#  # Install VGAM
#  install.packages("VGAM")
#  # Load VGAM
#  library(VGAM)
#  # Simulate a sample of size 100
#  x <- rzeta(n = 100, shape = 1)
#  # Calculate the sample mean
#  mean(x)

## ----message = FALSE----------------------------------------------------------
library(stat0002)
tbar <- mean(ox_births$time)
vart <- var(ox_births$time)
# Sample mean and variance
c(tbar, vart)
scale_par <- vart / tbar
shape_par <- tbar / scale_par
# Estimates of gamma shape and scale parameters
c(shape_par, scale_par)

## -----------------------------------------------------------------------------
# Produce the plot
curve(dgamma(x, shape = shape_par, scale = scale_par), 0, 20, ylab = "p.d.f.", xlab = "time (hours)")
gmode <- (shape_par - 1) * scale_par
gmode
# Indicate the mode
segments(gmode, 0, gmode, dgamma(gmode, shape = shape_par, scale = scale_par), lty =2)

## -----------------------------------------------------------------------------
# A function to calculate the (log of the) gamma p.d.f.
fn <- function(x, ...) dgamma(x, ...)
find_mode <- optim(1, fn, shape = shape_par, scale = scale_par, log = TRUE, 
                   method = "L-BFGS-B", lower = 0, control = list(fnscale = -1))
# Approximate value of the mode
find_mode$par
# Value of the p.d.f. at this value
exp(find_mode$value)

## -----------------------------------------------------------------------------
# Check that the p.d.f. integrates to 1
integrate(dgamma, 0, Inf, shape = shape_par, scale = scale_par)

## -----------------------------------------------------------------------------
# Check that the gamma mean is equal to the sample mean, tbar, of the data
integrand <- function(x, ...) x * dgamma(x, ...)
integrate(integrand, 0, Inf, shape = shape_par, scale = scale_par)
tbar

## -----------------------------------------------------------------------------
tmedian <- qgamma(1 / 2, shape = shape_par, scale = scale_par)
tmedian
qgamma(c(0.05, 0.5, 0.95), shape = shape_par, scale = scale_par)

## -----------------------------------------------------------------------------
# Two ways to check that the median is correct
integrate(dgamma, 0, tmedian, shape = shape_par, scale = scale_par)
pgamma(tmedian, shape = shape_par, scale = scale_par)

