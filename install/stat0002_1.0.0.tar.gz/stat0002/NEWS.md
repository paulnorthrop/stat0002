# stat0002 1.0.0

Version released to students at the start of the 2022-23 academic session
