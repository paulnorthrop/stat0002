## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE)
knitr::opts_knit$set(global.par = TRUE)

## ---- include = FALSE---------------------------------------------------------
# Set a random number `seed'.  
set.seed(2601)
# Set margins globally
par(mar = c(4, 4, 1, 1))

## -----------------------------------------------------------------------------
library(stat0002)
head(aussie_births)

## -----------------------------------------------------------------------------
nboys <- sum(aussie_births[, "sex"] == "boy")
ngirls <- sum(aussie_births[, "sex"] == "girl")
phat <- nboys / (nboys + ngirls)
phat

## ---- fig.align='center', fig.width=7-----------------------------------------
# Plot the binomial(44, 1/2) p.m.f. 
n <- nboys + ngirls
p <- 1 / 2
y <- 0:n
# Note that dbinom calculates the probabilities all values in the vector y
plot(y, dbinom(y, n, p), type = "h", lwd = 3, ylab = "P(Y = y)", xlab = "y")

## -----------------------------------------------------------------------------
# Calculate P(Y >= 26) = P(Y > 25) and P(Y <= 18)
pbinom(25, size = n, prob = 1 / 2, lower.tail = FALSE)
pbinom(18, n, 1 / 2)

## -----------------------------------------------------------------------------
qbinom(1 / 2, n, 1 / 2)
# A check (look at the definition of the median in the notes)
pbinom(21:23, n, 1 / 2)

## ---- fig.align='center', fig.width=7-----------------------------------------
ysim <- rbinom(100, 44, 1 / 2)
ysim
summary(ysim)

## -----------------------------------------------------------------------------
library(distributions3)
# (The warnings tell us that the distributions3 package has functions with the
# same names as functions from other packages and has `masked' them, that is,
# R will use these functions from distributions3, not the other functions.)
#
# Create an R object that is, effectively, a binomial(n, 1/2) random variable
Y <- Binomial(n, 1 / 2)
Y

## ---- fig.align='center', fig.width=7-----------------------------------------
# Reproduce the plot.  
plot(0:n, pmf(Y, 0:n), type = "h", lwd = 3, ylab = "P(X = x)", xlab = "x")
1 - cdf(Y, 25)
cdf(Y, 18)

## -----------------------------------------------------------------------------
# Observed, adding a zero for greater than or equal to 6
geom <- diff(c(0, which(aussie_births$sex == "boy")))
max_w <- max(geom)
geom <- c(1:(max_w + 1), geom)
obs_freq <- table(geom) - 1
obs_prop <- obs_freq / sum(obs_freq)
round(obs_prop, 3)

# Estimated expected, using dgeom
est_prob <- dgeom((1:max_w) - 1, prob = phat)
est_prob <- c(est_prob, 1 - sum(est_prob))
exp_freq <- nboys * est_prob

# The table
round(cbind(w = 1:(max_w + 1), obs_freq, exp_freq, obs_prop, est_prob), 3)

## -----------------------------------------------------------------------------
W <- Geometric(phat)
W
# P(W = w), for w = 1, ..., 5 (note the -1)
pmf(W, 1:5 - 1)
# P(W >= 6) = 1 - P(W < 6) = 1 - P(W <= 5)
1 - cdf(W, 5 - 1)

## -----------------------------------------------------------------------------
lambdahat <- 44 / 24
N <- Poisson(lambdahat)
N

## ---- fig.align='center', fig.width=7-----------------------------------------
plot(0:10, pmf(N, 0:10), type = "h", lwd = 3, ylab = "P(N = n)", xlab = "n")

pmf(N, 0:4)
# P(N >= 5)
1 - cdf(N, 4)

