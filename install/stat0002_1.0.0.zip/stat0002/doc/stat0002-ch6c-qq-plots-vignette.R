## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 6, fig.height = 6, fig.align = 'center')
knitr::opts_knit$set(global.par = TRUE)

## ---- include = FALSE---------------------------------------------------------
# Set margins globally
par(mar = c(4, 4, 1, 1))

## ---- warning = FALSE, message = FALSE----------------------------------------
library(stat0002)

## ---- echo = FALSE------------------------------------------------------------
set.seed(39)

## ---- fig.show='hold', out.width='47%', fig.align='default'-------------------
# Normal
normal <- rnorm(100)  
qqnorm(normal, pch = 16, xlab = "Theoretical N(0, 1) Quantiles", main = "normal")
qqline(normal, lwd = 3, lty = 2)
# Create an outlier
outlier <- normal
outlier[100] <- 6
qqnorm(outlier, pch = 16, xlab = "Theoretical N(0, 1) Quantiles", main = "outlier")
qqline(outlier, lwd = 3, lty = 2)

## ---- echo = FALSE------------------------------------------------------------
set.seed(39)

## ---- fig.show='hold', out.width='47%', fig.align='default'-------------------
# Heavy-tailed (Student's t distribution, with 2 degrees of freedom)
StudentsT <- rt(100, 2)
qqnorm(StudentsT, pch = 16, xlab = "Theoretical N(0, 1) Quantiles", main = "heavy-tailed")
qqline(StudentsT, lwd = 3, lty = 2)
# Light-tailed (Uniform(-3/4, 3/4))
uniform <- runif(100, -0.75, 0.75)
qqnorm(uniform, pch = 16, xlab = "Theoretical N(0, 1) Quantiles", main = "light-tailed")
qqline(uniform, lwd = 3, lty = 2)

## ---- fig.show='hold', out.width='47%', fig.align='default'-------------------
# Positively skewed (gamma(2, 1) distribution)
gam <- rgamma(100, shape = 2)
qqnorm(gam, pch = 16, xlab = "Theoretical N(0, 1) Quantiles", main = "positive skew")
qqline(gam, lwd = 3, lty = 2)
# Negatively skewed (10 - gamma(2, 1) distribution)
neggam <- 10 - rgamma(100, 2)
qqnorm(neggam, pch = 16, xlab = "Theoretical N(0, 1) Quantiles", main = "negative skew")
qqline(neggam, lwd = 3, lty = 2)

## -----------------------------------------------------------------------------
# Calculate the waiting times until each birth
waits <- diff(c(0, aussie_births[, "time"]))
# Produce the QQ plot
lambdahat <- qqexp(waits, envelopes = 19)
# Estimate of lambda: rate of births per hour
lambdahat * 60

## -----------------------------------------------------------------------------
lambdahat2 <- qqexp(waits, statistic = "median", envelopes = 19, pch = 16,
                    line = list(lty = 2, lwd = 2, col= "blue"))
# Estimate of lambda calculated from the sample median
lambdahat2 * 60

