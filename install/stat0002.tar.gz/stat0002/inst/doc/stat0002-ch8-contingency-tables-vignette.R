## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 7, fig.height = 5, fig.align = 'center')

required <- c("vcd")

if (!all(unlist(lapply(required, function(pkg) requireNamespace(pkg, quietly = TRUE)))))
  knitr::opts_chunk$set(eval = FALSE)

## ----message = FALSE----------------------------------------------------------
library(stat0002)

## -----------------------------------------------------------------------------
# Find the dimensions of the data
dim(berkeley)
# What type of R object is berkeley?
class(berkeley)
# Print the data
berkeley

## ----genderadmit--------------------------------------------------------------
berkdf <- as.data.frame(berkeley)
berkdf
ga <- xtabs(Freq ~ Gender + Admit, berkdf)
ga

## -----------------------------------------------------------------------------
# Total number of applicants
marginSums(ga)
# Number of males and females
marginSums(ga, "Gender")
# Number of admitted and rejected applicants
marginSums(ga, "Admit")
# Add the marginal totals to the table
addmargins(ga)
# Calculate proportions (relative frequencies)
proportions(ga)
# Row proportions (sum to 1 across the rows)
proportions(ga, "Gender")
# Column proportions (sum to 1 down the columns)
proportions(ga, "Admit")

## -----------------------------------------------------------------------------
class(ga)

## -----------------------------------------------------------------------------
plot(ga, main = "Observed frequencies", color = TRUE)

## -----------------------------------------------------------------------------
plot(ga, main = "Observed frequencies", color = TRUE, dir = c("h", "v"))

## -----------------------------------------------------------------------------
ag <- xtabs(Freq ~ Admit + Gender, berkdf)
ag
# Alternatively, we could have transposed ga
t(ga)
plot(ag, main = "Observed frequencies", color = TRUE)

## -----------------------------------------------------------------------------
plot(ag, main = "Observed frequencies", color = TRUE, sort = 2:1)

## -----------------------------------------------------------------------------
efreq <- outer(marginSums(ga, "Gender"), marginSums(ga, "Admit")) / marginSums(ga)
efreq
# Check using chisq.test
efreq <- chisq.test(ga)$expected
efreq
# Trick R into using plot.table
class(efreq) <- "table"
# Plot estimated expected frequencies
plot(efreq, main = "Estimated expected frequencies", color = TRUE, 
     dir = c("h", "v"))

## -----------------------------------------------------------------------------
assocplot(ga, col = c("black", "grey"))

## -----------------------------------------------------------------------------
chisq.test(ga, correct = FALSE)

## ----warning = FALSE, message = FALSE-----------------------------------------
library(vcd)
# Extract the standardised Pearson residuals
x2test <- chisq.test(ga)
# Raw residuals
x2test$observed - x2test$expected
# Pearson residuals
x2test$residuals
# Standardised Pearson residuals
x2test$stdres
# Association plot of residuals with Pearson residual shading
assoc(ga, shade = TRUE, margins = c(2.25, 1, 1, 2.5))
# Association plot of residuals with standardised Pearson residual shading
strucplot(ga, shade = TRUE, residuals = x2test$stdres, 
          margins = c(2.25, 1, 1, 2.5),
          residuals_type = "Standardised\nPearson\nresiduals", core = struc_assoc,
          keep_aspect_ratio = FALSE, legend_width = 6)
# Mosaic plot with standardised Pearson residual shading
mosaic(ga, shade = TRUE, residuals = x2test$stdres, 
       residuals_type = "Standardised Pearson", margins = c(0, 0, 0, 0))

## -----------------------------------------------------------------------------
b <- berkeley
dimnames(b)$Admit <- c("A", "R")
dimnames(b)$Gender <- c("M", "F")
plot(b, main = "Observed frequencies", sort = 3:1, color = c(1, 8))

## -----------------------------------------------------------------------------
summary(berkeley, correction = FALSE)

## -----------------------------------------------------------------------------
assoc2 <- function(tab, residuals, ...) {
  strucplot(tab, shade = TRUE, residuals = residuals, 
            residuals_type = "Standardised Pearson", core = struc_assoc, ...)
}

## -----------------------------------------------------------------------------
gd <- xtabs(Freq ~ Gender + Dept, berkdf)
x2test <- chisq.test(gd, correct = FALSE)
assoc2(gd, residuals = x2test$stdres, margins = c(0, 0, 0, 0))

## -----------------------------------------------------------------------------
ad <- xtabs(Freq ~ Admit + Dept, berkdf)
x2test <- chisq.test(ad, correct = FALSE)
assoc2(ad, residuals = x2test$stdres, margins = c(0, 0, 0, 0))

## ----fig.height = 10----------------------------------------------------------
cotabplot(~ Admit + Gender | Dept, data = berkeley, layout = 3:2, shade = TRUE,
          panel = cotab_assoc)

## -----------------------------------------------------------------------------
# A function to produce an association plot within a given department
deptplot <- function(dept) {
  temp <- xtabs(Freq ~ Admit + Gender, berkdf, 
                subset = berkdf[, "Dept"] == dept)
  x2test <- chisq.test(temp, correct = FALSE)
  assoc2(temp, residuals = x2test$stdres, main = paste("Dept ", dept))
  return(x2test$stdres)
}

## -----------------------------------------------------------------------------
deptplot("A")

