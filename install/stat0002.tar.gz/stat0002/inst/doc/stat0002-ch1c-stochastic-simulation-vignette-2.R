## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = FALSE, collapse = TRUE)

## ----setup, echo = FALSE, warning = FALSE-------------------------------------
options(rgl.useNULL = TRUE)
library(rgl)
rgl::setupKnitr(autoprint = TRUE)
#knitr::knit_hooks$set(webgl = hook_webgl)

## ----RANDUfunction------------------------------------------------------------
randu <- function(N, X0 = 1) {
  #
  # Generates N successive triplets from the RANDU PRNG  
  #
  # Arguments:
  #   N  - an integer. The number of successive triplets required.
  #   X0 - an integer. The value of the seed, the default value is 1.
  # Returns:
  #   An N by 3 numeric matrix.  Row i contains the ith triplet.
  #
  res <- numeric(N + 2)
  res[1] <- X0    
  m <- 2 ^ 31
  for (i in 2 + (0:N)) {
    res[i] <- (65539 * res[i - 1]) %% m
  }  
  res <- res / m
  return(embed(res, 3))
}

## ----RANDUcall----------------------------------------------------------------
randu <- randu(10000)

## ----RANDU, fig.alt = "3D scatter plot of successive triplets from the RANDU generator. When the plot is rotated we can see that the points lie on 2D planes in 3D space.", fig.width = 5, fig.height = 5, warning = FALSE----
library(rgl)
par(mar = c(0, 0, 0, 0))
plot3d(randu[, 1], randu[, 2], randu[, 3], xlab = expression(u[i]), 
       ylab = expression(u[i + 1]), zlab = expression(u[i + 2]))

## ----runif, fig.alt = "3D scatter plot of successive triplets from the RANDU generator. When the plot is rotated we cannot see any obvious structure.", fig.width = 5, fig.height = 5, results = 'hide', warning = FALSE----
x <- embed(runif(10000 + 2), 3)
par(mar = c(0, 0, 0, 0))
plot3d(x[, 1], x[, 2], x[, 3], xlab = expression(u[i]), 
       ylab = expression(u[i + 1]), zlab = expression(u[i + 2]))

## -----------------------------------------------------------------------------
runif(6)

## -----------------------------------------------------------------------------
runif(6)

## -----------------------------------------------------------------------------
# Set a random number `seed'.  
set.seed(29052020)
runif(6)
set.seed(29052020)
runif(6)

## -----------------------------------------------------------------------------
rbinomial <- function(size, prob) {
  #
  # Simulates one value from a binomial(size, prob) distribution in a direct,  
  # but inefficient, way.
  #
  # Arguments:
  #   size - an integer. The number of independent Bernoulli trials.
  #   prob - a number in [0, 1] integer. The probability of success.
  # Returns:
  #   An integer: the total number of successes in size trials.
  #
  # Simulate size values (pseudo-)randomly between 0 and 1.
  u <- runif(size)
  # Find out whether (TRUE) or not (FALSE) each value of u is less than p.
  outcome <- u < prob
  # Count the number of TRUEs, i.e. the number of successes.
  n_successes <- sum(outcome)
  # Return the number of successes.
  return(n_successes)
}

## -----------------------------------------------------------------------------
set.seed(2020)
rbinomial(size = 6, prob = 0.2)

## -----------------------------------------------------------------------------
set.seed(2020)
size <- 6
prob <- 0.2
u <- runif(size)
u
outcome <- u < prob
outcome
n_successes <- sum(outcome)
n_successes

## -----------------------------------------------------------------------------
as.numeric(outcome)

## -----------------------------------------------------------------------------
rbinom(n = 1, size = 6, prob = 0.2)
rbinom(n = 10, size = 6, prob = 0.2)

## ----fig.show='hold'----------------------------------------------------------
lambda <- 2
exp_sim <- rexp(n = 1000, rate = lambda)

## ----fig.show='hold', fig.width = 6, fig.height = 4, fig.alt = "Histogram of a sample of size 1000 simulated from an exponential distribution with mean 1/2, with the corresponding pdf superimposed."----
par(mar = c(4, 4, 1, 1))
hist(exp_sim, probability = TRUE, ylim = c(0, lambda), main = "", xlab = "t", ylab = "density")
x <- seq(0, max(exp_sim), len = 500)
lines(x, dexp(x, rate = lambda))

## ----fig.show='hold', fig.width = 6, fig.height = 4, fig.alt = "Histogram of a sample of size 1000 simulated from an exponential distribution with mean 1/2, with the corresponding pdf superimposed."----
u <- runif(1000)
exp_inv <- -log(u)/lambda
par(mar = c(4, 4, 1, 1))
hist(exp_inv, probability = TRUE, ylim = c(0, lambda), main = "", xlab = "t", ylab = "density")
lines(x, dexp(x, rate = lambda))

## ----fig.width = 6, fig.height = 4, fig.alt = "Histogram of a sample of size 1000 simulated from a standard normal distribution, with the corresponding pdf superimposed."----
u <- runif(1000)
mu <- 0
sigma <- 1
norm_sim <- qnorm(u, mean = mu, sd = sigma)
hist(norm_sim, probability = TRUE, main = "", col = "grey", 
     xlab = "simulated value")
x <- seq(min(norm_sim), max(norm_sim), len = 500)
lines(x, dnorm(x, mean = mu, sd = sigma))

## -----------------------------------------------------------------------------
u <- runif(10000)
mean(u)

## ----fig.alt = "Plot of the sample mean of a sample of size n from a standard uniform distribution against n. As n increases the value of the sample mean is variable but it tends to become closer to 1/2."----
m <- cumsum(u) / seq_along(u)
plot(seq_along(u), m, type = "l", xlab = "n", ylab = expression(estimate~of~E(X)))
abline(h = 1/2, col = "blue", lty = 2)

## ----fig.alt = "Plot of the estimate of pi based on a function of a sample of size n from a standard uniform distribution against n. As n increases the value of the sample mean is variable but it tends to become closer to pi."----
n <- 1000
x <- runif(n)
y <- sqrt(1 - x ^ 2)
theta <- 4 * cumsum(y) / seq_len(n)
plot(1:n, theta, type = "l", xlab = "n", ylab = expression(estimate~of~pi))
abline(h = pi, col = "blue", lty = 2)

## ----echo = FALSE-------------------------------------------------------------
rSIR <- function(N0 = 1000, I0 = 0, S0 = N0 - I0, days = 100, 
                 pars = c(1, 0.1, 2, 1, 0.9)) {
  #
  # Simulates from a simple stochastic SIR epidemic model
  #
  # Arguments:
  #   N0     - an integer. The population size at time 0.
  #   I0     - an integer. The initial number of infected people.
  #   S0     - an integer. The initial number of susceptible people.
  #   R0     - an integer. The initial number of recovered people.
  #   days   - an integer. The number of days for which to simulate.
  #   pars   - a numeric vector: (alpha, pI, beta, pR, gamma). 
  #     alpha : rate of arrival of people into the population
  #     pI    : probability that an arrival is infected
  #     beta  : individual infection rate at time t is beta / Nt
  #     gamma : recovery rate for each infected individual
  #     pR    : probability that an infected person is immune after recovery
  #   
  # Returns:
  #   A numeric matrix with 5 columns.  Row i contains the values of 
  #   (t, S_t, I_t, R_t, N_t) immediately after transition i - 1.
  #
  # Checks:
  if (I0 + S0 > N0) {
    stop("There can be at most N people who are susceptible or infected")
  }
  # Infer the number of recovered people
  R0 <- N0 - I0 - S0
  # The initial state, at time = 0
  x <- c(0, S0, I0, R0, N0)
  # A list in which to store the results
  res <- list()
  i <- 1
  # Simulate the next change, or jump, in the process until days have passed
  while (x[1] < days) {
    res[[i]] <- x
    x <- SIRjump(x, pars)
    i <- i + 1
  }
  # Convert the list to a matrix
  res <- do.call(rbind, res)
  colnames(res) <- c("t", "St", "It", "Rt", "Nt")
  return(res)
}

SIRjump <- function (x, pars) {
  #
  # Simulates one jump from a simple stochastic SIS epidemic model
  #
  # Arguments:
  #   x    - a numeric vector: (time, S, I, R, N) at the previous jump.
  #   pars - a numeric vector: (alpha, pI, beta, gamma, pR). 
  #   
  # Returns:
  #   a numeric vector: (time, S, I, R, N) immediately after the next jump  
  #
  # The numbers of susceptible and infected people and the population size
  St <- x[2]
  It <- x[3]
  Rt <- x[4]
  Nt <- x[5]
  # The parameter values
  alpha <- pars[1]
  pI <- pars[2]
  beta <- pars[3]
  gamma <- pars[4]
  pR <- pars[5]
  # Simulate the time at which the next transition occurs
  total_rate <- alpha + beta * St * It / Nt + gamma * It
  x[1] <- x[1] + rexp(1, total_rate)
  # Jump probabilities
  p1 <- alpha * pI / total_rate
  p2 <- alpha * (1 - pI) / total_rate
  p3 <- gamma * pR * It / total_rate
  p4 <- gamma * (1 - pR) * It / total_rate
  u <- runif(1)
  if (u < p1) {
    # Arrival of a new infected person It increases by 1, Nt increases by 1
    x[3] <- x[3] + 1 
    x[5] <- x[5] + 1 
  } else if (u < p1 + p2) {
    # Arrival of a new susceptible person St increases by 1, Nt increases by 1
    x[2] <- x[2] + 1 
    x[5] <- x[5] + 1 
  } else if (u < p1 + p2 + p3) {
    # Infected person becomes immune: It decreases by 1, Rt increases by 1
    x[3] <- x[3] - 1
    x[4] <- x[4] + 1 
  } else if (u < p1 + p2 + p3 + p4) {
    # Infected person becomes susceptible: It decreases by 1, St increases by 1
    x[3] <- x[3] - 1
    x[2] <- x[2] + 1 
  } else {
    # Infection of a susceptible: St decreases by 1, It increases by 1
    x[2] <- x[2] - 1
    x[3] <- x[3] + 1 
  }
  return(x)
}

## ----fig.show = 'hold', fig.width = 7, fig.height = 5, fig.alt = "Plot of the numbers of people who are susceptible, infected, immune and the total population. The number who are infected increases initially and the drops back towards zero as the number who are susceptible (not immune) decreases."----
set.seed(31052020)
# parameters: (alpha, pI, beta, pR, gamma)
pars1 <- c(1/10, 0.1, 1, 1/5, 0.9)
I0 <- 10
r1 <- rSIR(pars = pars1, I0 = I0)
par(mar = c(4, 4, 1, 1))
leg <- c("susceptible", "infected", "immune", "population")
matplot(r1[, 1], r1[, -1], type = "l", lty = 1, lwd = 2, col = 1:4, 
        ylab = "number of people", xlab = "time / days")
legend("right", legend = leg, lty = 1, lwd = 2, col = 1:4, bg = "transparent")

## ----fig.show = 'hold', fig.width = 7, fig.height = 5, fig.alt = "Plot containing the profile of the number of infected people over time for 100 different simulations from the SIR model."----
set.seed(31052020)
r1 <- rSIR(pars = pars1, I0 = I0)
par(mar = c(4, 4, 1, 1))
matplot(r1[, 1], r1[, 3], type = "l", ylab = "number of infected people", 
        xlab = "time / days", ylim = c(0, 550), col = 2)
nsim <- 100
gt500 <- numeric(nsim)
gt500[1] <- any(r1[, 3] > 500)
for (i in 2:nsim) {
  r2 <- rSIR(pars = pars1, I0 = I0)
  matlines(r2[, 1], r2[, 3], col = 2)
  gt500[i] <- any(r2[, 3] > 500)
}
abline(h = 500, lty = 2)
mean(gt500)

## ----fig.show = 'hold', fig.width = 7, fig.height = 5, fig.alt = "Plot of the numbers of people who are susceptible, infected, immune and the total population. Now that post-infection immunity is more unlikely the number who are infected drops back towards zero more slowly than when post-infection immunity is likely."----
set.seed(31052020)
# parameters: (alpha, pI, beta, pR, gamma)
pars2 <- c(1/10, 0.1, 1, 1/5, 0.1)
r2 <- rSIR(pars = pars2, I0 = I0, days = 200)
par(mar = c(4, 4, 1, 1))
matplot(r2[, 1], r2[, -1], type = "l", lty = 1, lwd = 2, col = 1:4, 
        ylab = "number of people", xlab = "time / days")
legend("right", legend = leg, lty = 1, lwd = 2, col = 1:4, bg = "transparent")

## ----echo = TRUE--------------------------------------------------------------
rSIR <- function(N0 = 1000, I0 = 0, S0 = N0 - I0, days = 100, 
                 pars = c(1, 0.1, 2, 1, 0.9)) {
  #
  # Simulates from a simple stochastic SIR epidemic model
  #
  # Arguments:
  #   N0     - an integer. The population size at time 0.
  #   I0     - an integer. The initial number of infected people.
  #   S0     - an integer. The initial number of susceptible people.
  #   R0     - an integer. The initial number of recovered people.
  #   days   - an integer. The number of days for which to simulate.
  #   pars   - a numeric vector: (alpha, pI, beta, pR, gamma). 
  #     alpha : rate of arrival of people into the population
  #     pI    : probability that an arrival is infected
  #     beta  : individual infection rate at time t is beta / Nt
  #     gamma : recovery rate for each infected individual
  #     pR    : probability that an infected person is immune after recovery
  #   
  # Returns:
  #   A numeric matrix with 5 columns.  Row i contains the values of 
  #   (t, S_t, I_t, R_t, N_t) immediately after transition i - 1.
  #
  # Checks:
  if (I0 + S0 > N0) {
    stop("There can be at most N people who are susceptible or infected")
  }
  # Infer the number of recovered people
  R0 <- N0 - I0 - S0
  # The initial state, at time = 0
  x <- c(0, S0, I0, R0, N0)
  # A list in which to store the results
  res <- list()
  i <- 1
  # Simulate the next change, or jump, in the process until days have passed
  while (x[1] < days) {
    res[[i]] <- x
    x <- SIRjump(x, pars)
    i <- i + 1
  }
  # Convert the list to a matrix
  res <- do.call(rbind, res)
  colnames(res) <- c("t", "St", "It", "Rt", "Nt")
  return(res)
}

SIRjump <- function (x, pars) {
  #
  # Simulates one jump from a simple stochastic SIS epidemic model
  #
  # Arguments:
  #   x    - a numeric vector: (time, S, I, R, N) at the previous jump.
  #   pars - a numeric vector: (alpha, pI, beta, gamma, pR). 
  #   
  # Returns:
  #   a numeric vector: (time, S, I, R, N) immediately after the next jump  
  #
  # The numbers of susceptible and infected people and the population size
  St <- x[2]
  It <- x[3]
  Rt <- x[4]
  Nt <- x[5]
  # The parameter values
  alpha <- pars[1]
  pI <- pars[2]
  beta <- pars[3]
  gamma <- pars[4]
  pR <- pars[5]
  # Simulate the time at which the next transition occurs
  total_rate <- alpha + beta * St * It / Nt + gamma * It
  x[1] <- x[1] + rexp(1, total_rate)
  # Jump probabilities
  p1 <- alpha * pI / total_rate
  p2 <- alpha * (1 - pI) / total_rate
  p3 <- gamma * pR * It / total_rate
  p4 <- gamma * (1 - pR) * It / total_rate
  u <- runif(1)
  if (u < p1) {
    # Arrival of a new infected person It increases by 1, Nt increases by 1
    x[3] <- x[3] + 1 
    x[5] <- x[5] + 1 
  } else if (u < p1 + p2) {
    # Arrival of a new susceptible person St increases by 1, Nt increases by 1
    x[2] <- x[2] + 1 
    x[5] <- x[5] + 1 
  } else if (u < p1 + p2 + p3) {
    # Infected person becomes immune: It decreases by 1, Rt increases by 1
    x[3] <- x[3] - 1
    x[4] <- x[4] + 1 
  } else if (u < p1 + p2 + p3 + p4) {
    # Infected person becomes susceptible: It decreases by 1, St increases by 1
    x[3] <- x[3] - 1
    x[2] <- x[2] + 1 
  } else {
    # Infection of a susceptible: St decreases by 1, It increases by 1
    x[2] <- x[2] - 1
    x[3] <- x[3] + 1 
  }
  return(x)
}

