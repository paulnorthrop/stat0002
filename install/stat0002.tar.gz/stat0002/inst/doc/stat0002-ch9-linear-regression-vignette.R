## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 7, fig.height = 5, fig.align = 'center')

required <- c("vcd")

if (!all(unlist(lapply(required, function(pkg) requireNamespace(pkg, quietly = TRUE)))))
  knitr::opts_chunk$set(eval = FALSE)

## ---- message = FALSE---------------------------------------------------------
library(stat0002)

## -----------------------------------------------------------------------------
hubble
plot(rev(hubble), pch = 16)

## -----------------------------------------------------------------------------
l3 <- lm(distance ~ velocity, data = hubble)
l3 
coef(l3)

## -----------------------------------------------------------------------------
slm <- function(y, x, rto = FALSE) {
  # If only response data are provided then fit a horizontal line y = mean(y)
  if (missing(x)) {
    residuals <- y - mean(y)
    rss <- sum(residuals ^ 2)
    n <- length(y)
    estimates <- mean(y)
    names(estimates) <- "(Intercept)"
    res <- list(coefficients = estimates, fitted.values = mean(y),
                residuals = y - mean(y), rss = rss, 
                sigmahat = sqrt(rss / (n - 1)), y = y, call = match.call())
    class(res) <- "lm"
    return(res)
  }
  # Check that y and x have the same length  
  if (length(y) != length(x)) {
    stop("''y'' and ''x'' must have the same length")
  }
  # Calculate the estimates.  If rto = FALSE (the default) then we estimate 
  # both alpha and beta from the data.  If rto = TRUE then we set alpha = 0
  # and estimate only beta from the data.
  ybar <- mean(y)
  if (rto) {
    betahat <- mean(x * y) / mean(x ^ 2)
    alphahat <- 0
    estimates <- betahat
    names(estimates) <- deparse(substitute(x))
  } else {
    xbar <- mean(x)
    betahat <- mean((x - xbar) * (y - ybar)) / mean((x - xbar) ^ 2)
    alphahat <- ybar - betahat * xbar
    estimates <- c(alphahat, betahat)
    names(estimates) <- c("(Intercept)", deparse(substitute(x)))
  }
  # Calculate the fitted values for y, residuals and residual sum of squares
  fittedy <- alphahat + betahat * x
  residuals <- y - fittedy
  rss <- sum(residuals ^ 2)
  # Estimate of the error standard deviation sigma
  n <- length(y)
  p <- length(estimates)
  sigmahat <- sqrt(rss / (n - p))
  # Create the results list 
  res <- list(coefficients = estimates, fitted.values = fittedy, 
              residuals = residuals, rss = rss, sigmahat = sigmahat,
              y = y, x = x, call = match.call())  
  class(res) <- "lm"
  return(res)
}

## -----------------------------------------------------------------------------
# Model 3
m3 <- slm(y = hubble$distance, x = hubble$velocity)
m3
plot(rev(hubble), pch = 16)
abline(coef = coef(m3))

## -----------------------------------------------------------------------------
# Model 1
# ~1 means that there is no explanatory variable in the model
m1 <- slm(y = hubble$distance)
l1 <- lm(distance ~ 1, data = hubble)
coef(m1)
coef(l1)

# Model 2
# The -1 removes the intercept from the model
m2 <- slm(y = hubble$distance, x = hubble$velocity, rto = TRUE)
l2 <- lm(distance ~ velocity - 1, data = hubble)
coef(m2)
coef(l2)

## -----------------------------------------------------------------------------
m3$sigmahat
sigma(m3)
sigma(l3)

## -----------------------------------------------------------------------------
stres <- function(slmfit) {
  # The generic function nobs tries to calculate the number of observations
  n <- nobs(slmfit)
  # Extract the values of the explanatory variables
  x <- slmfit$x
  # Calculate the leverage value for each observation
  sx2 <- (x - mean(x)) ^ 2
  hii <- 1 / n + sx2 / sum(sx2)
  return(slmfit$residuals / (slmfit$sigmahat * sqrt(1 - hii ^ 2)))
}

## -----------------------------------------------------------------------------
plot(m3$x, m3$residual, ylab = "residual", xlab = "velocity", pch = 16)
abline(h = 0, lty = 2)

## -----------------------------------------------------------------------------
plot(m3$fitted.values, m3$residual, ylab = "residual", xlab = "fitted values", pch = 16)
abline(h = 0, lty = 2)

## -----------------------------------------------------------------------------
stresiduals <- stres(m3)
qqnorm(stresiduals, ylab = "Standardised Residuals")
qqline(stresiduals)

## -----------------------------------------------------------------------------
# By default, the 3 residuals with the largest magnitudes are labelled by their observation number
plot(l3, which = 2)

