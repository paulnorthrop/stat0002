## ----chunks, include = FALSE--------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE, eval = FALSE)

## ----getwd--------------------------------------------------------------------
# getwd()

## ----accessr------------------------------------------------------------------
# # Load accessr
# library(accessr)
# # Knit and render to Word
# rmd2word("ex1template", pdf = FALSE)
# # Knit and render to HTML
# rmd2html("ex1template", pdf = FALSE)

## ----install_otp--------------------------------------------------------------
# # Install OfficeToPDF from https://github.com/cognidox/OfficeToPDF/releases
# install_otp(dir = "accessr")

## ----accessr_word_pdf---------------------------------------------------------
# # Knit and render to Word and PDF
# # (Microsoft Windows only)
# rmd2word("ex1template", pdf = TRUE)

## ----accessr_html_pdf---------------------------------------------------------
# # Knit and render to HTML and print to PDF
# # (Need a browser, such as Google Chrome or Microsoft Edge)
# rmd2html("ex1template", pdf = TRUE)

## ----stat0002-----------------------------------------------------------------
# # Load stat0002
# library(stat0002)
# word("ex1template", pdf = FALSE)
# html("ex1template", pdf = FALSE)

