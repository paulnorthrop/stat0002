## ----chunks, include = FALSE--------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE, eval = FALSE)

## ----getwd--------------------------------------------------------------------
# getwd()

## ----install_for_accessr------------------------------------------------------
# install.packages("accessr")
# # officer and officedown are only needed if you wish to output to Word format
# install.packages(c("officer", "officedown"))

## ----accessr------------------------------------------------------------------
# # Load accessr
# library(accessr)
# # Knit and render to Word
# rmd2word("ex1template", pdf = FALSE)
# # Knit and render to HTML
# rmd2html("ex1template", pdf = FALSE)

## ----install_otp--------------------------------------------------------------
# # Install OfficeToPDF from https://github.com/cognidox/OfficeToPDF/releases
# install_otp(dir = "accessr")

## ----accessr_word_pdf---------------------------------------------------------
# # Knit and render to Word and PDF
# # (Microsoft Windows only)
# rmd2word("ex1template", pdf = TRUE)

## ----install_for_html_print---------------------------------------------------
# # pagedown is only need if you wish to print from HTML to PDF
# install.packages("pagedown")

## ----accessr_html_pdf---------------------------------------------------------
# # Knit and render to HTML and print to PDF
# # (Need a browser, such as Google Chrome or Microsoft Edge)
# rmd2html("ex1template", pdf = TRUE)

## ----stat0002-----------------------------------------------------------------
# # Load stat0002
# library(stat0002)
# word("ex1template", pdf = FALSE)
# html("ex1template", pdf = FALSE)

