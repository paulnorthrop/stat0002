## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(comment = "", prompt = TRUE, collapse = TRUE,
                      fig.width = 7, fig.height = 5, fig.align = 'center')

## ----message = FALSE----------------------------------------------------------
library(stat0002)

## ----kerrichplot--------------------------------------------------------------
# This code produces the plot in Figure 3.1 of the STAT0002 notes
plot(kerrich$throws, kerrich$heads / kerrich$throws,
     ylab = "proportion of heads",
     xlab = "number of throws (logarithmic scale)", lwd = 2, type = "l",
     log = "x", ylim = c(0,1), axes = FALSE)
abline(h = 0.5, lty = 2)
axis(1, labels = as.character(c(3, 10, 30, 100, 300, 1000, 3000, 10000)),
     at=c(3, 10, 30, 100, 300, 1000, 3000, 10000))
axis(2, labels = c(0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0),
     at=c(0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0))

## ----estimatep----------------------------------------------------------------
trials <- kerrich[nrow(kerrich), "throws"]
heads <- kerrich[nrow(kerrich), "heads"]
c(heads, trials)
phat <- heads / trials
phat

## ----berk2way-----------------------------------------------------------------
# 2-way table: sex and outcome
sex_outcome <- apply(berkeley, 2:1, FUN = sum)
colnames(sex_outcome) <- c("A", "R")
rownames(sex_outcome) <- c("M", "F")
sex_outcome

## ----berk2wayplustotals-------------------------------------------------------
# Add column totals
sex_outcome <- rbind(sex_outcome, total = colSums(sex_outcome))
# Add row totals
sex_outcome <- cbind(sex_outcome, total = rowSums(sex_outcome))
sex_outcome

## ----berkprobs----------------------------------------------------------------
# Convert frequencies to probabilities
pso <- sex_outcome/ sex_outcome[3, 3]
round(pso, 3)

## ----bloodtypes---------------------------------------------------------------
blood_types

## ----bloodcalcs---------------------------------------------------------------
aggregate(percentage ~ Rh, data = blood_types, FUN = sum) 
aggregate(percentage ~ ABO, data = blood_types, FUN = sum)

## ----bloodcalcs2--------------------------------------------------------------
propn <- function(x) sum(x) / 100
aggregate(percentage ~ Rh, data = blood_types, FUN = propn) 
aggregate(percentage ~ ABO, data = blood_types, FUN = propn)

