#' stat0002: Introduction to Probability and Statistics at UCL
#'
#' Provides example datasets, R code and tutorials to help students taking
#' STAT0002 Introduction to Probability and Statistics at
#' University College London to understand the course material and to see how
#' R can be used to perform some of the analyses in the course.
#' This package can also be used to complement STAT0004 Introduction to
#' Practical Statistics, enabling students to become more familiar with R
#' code by seeing it in action and playing with it themselves.
#'
#' The most useful source of information is the
#' \href{https://paulnorthrop.github.io/stat0002/}{stat0002 home page on GitHub}.
#' The \href{https://paulnorthrop.github.io/stat0002/reference/index.html}{Reference}
#' page provides information about example datasets, movies (interactive plots),
#' and functions for performing tasks like creating plot, calculating summary
#' statistics and simulating data.
#'
#' The tab labelled \strong{Articles} (or use the
#' \href{https://paulnorthrop.github.io/stat0002/articles/}{Articles link}) contains
#' several tutorials demonstrating how to use R to create some of the content
#' of the \href{https://paulnorthrop.github.io/stat0002book/}{STAT0002 notes}
#' and related tasks.
#'
#' Some of the movies are made available via the
#' \href{https://paulnorthrop.github.io/smovie/}{smovie} package.  You can
#' access a menu for the movies in smovie using \code{library(smovie)} and then
#' \code{movies()}. See
#' \href{https://paulnorthrop.github.io/smovie/reference/movies.html}{movies}
#' for more details.
#'
#' @section Summary of the main resources:
#' \itemize{
#'   \item {\href{https://paulnorthrop.github.io/stat0002/articles/}{Tutorials}}
#'   \item {\href{https://paulnorthrop.github.io/stat0002/reference/index.html#example-data}{Example data}}
#'   \item {\href{https://paulnorthrop.github.io/stat0002/reference/index.html#movies}{Movies}. See also \link[=stat0002movies]{movies}}
#'   \item {\href{https://paulnorthrop.github.io/stat0002/reference/index.html#plots}{Plots}}
#'   \item {\href{https://paulnorthrop.github.io/stat0002/reference/index.html#summary-statistics}{Summary statistics}}
#'   \item {\href{https://paulnorthrop.github.io/stat0002/reference/index.html#simulation-functions}{Simulation functions}}
#' }
#'
#'
#' @section Please note:
#' \strong{The main source of information about the material in STAT0002 is
#' the
#' \href{https://moodle.ucl.ac.uk/course/view.php?id=8579&section=0}{STAT0002 Moodle page}.
#' You are not required to use the `stat0002` package during STAT0002, but it
#' is recommended as a supplement to the STAT0002 syllabus.}
#'
#' @section How to learn about R:
#' The best way to learn how to use a computer program is to play with code and
#' see what it does.  R is based on \strong{functions} that look like \code{name()}, where
#' \code{name} is the name of the function and where various \strong{arguments} are inserted
#' inside the brackets \code{()}.  In the R code provided with this package you will
#' see many functions like this.  To find out what a function called \code{name} does
#' use either \code{?name} or \code{help(name)}.
#'
#' If you have any questions about this package please ask them via the
#' stat0002 R package Moodle Forum.
#'
#' @docType package
#' @importFrom stats runif
#' @importFrom graphics plot
#' @importFrom distributions3 cdf
#' @importFrom rust ru
#' @importFrom MASS boxcox
#' @importFrom grDevices nclass.Sturges
#' @importFrom plotrix addtable2plot
#' @aliases stat0002-package
#' @aliases stat0002
"_PACKAGE"
